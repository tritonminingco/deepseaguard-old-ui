import React, { useState } from 'react';
import '../styles/panels/ComplianceStatus.css';

function ComplianceStatus({ data, selectedAUV, timeFrame }) {
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportType, setReportType] = useState('daily');

  if (!data) {
    return (
      <div className="panel-container">
        <div className="no-data">
          <p>No compliance data available</p>
          <p className="help-text">Select an AUV to view compliance status</p>
        </div>
      </div>
    );
  }

  const complianceRules = [
    {
      id: 'ISA-ENV-1',
      name: 'Sediment Discharge',
      currentValue: data.sedimentThreshold || 18.5,
      threshold: 25,
      unit: 'mg/L',
      status: (data.sedimentThreshold || 18.5) > 25 ? 'violation' : 'compliant',
      description: 'Maximum sediment discharge per ISA regulations'
    },
    {
      id: 'ISA-ENV-2',
      name: 'Sensitive Zone Time',
      currentValue: data.sensitiveZoneTime === '0m' ? 0 : 135, // 2h 15m = 135 minutes
      threshold: 120, // 2 hours
      unit: 'minutes',
      status: data.sensitiveZoneTime !== '0m' && data.sensitiveZoneTime !== '0' ? 'violation' : 'compliant',
      description: 'Maximum time in sensitive ecological zones'
    },
    {
      id: 'ISA-OPS-1',
      name: 'Operational Depth',
      currentValue: 2450,
      threshold: 3000,
      unit: 'm',
      status: 'compliant',
      description: 'Maximum operational depth for mining activities'
    },
    {
      id: 'ISA-REP-1',
      name: 'Reporting Frequency',
      currentValue: 24,
      threshold: 24,
      unit: 'hours',
      status: 'compliant',
      description: 'Mandatory reporting interval'
    }
  ];

  const getComplianceColor = (status) => {
    switch (status) {
      case 'compliant': return 'var(--accent-green)';
      case 'violation': return 'var(--accent-red)';
      case 'warning': return 'var(--accent-yellow)';
      default: return 'var(--text-medium)';
    }
  };

  const getComplianceIcon = (status) => {
    switch (status) {
      case 'compliant': return '✅';
      case 'violation': return '❌';
      case 'warning': return '⚠️';
      default: return '❓';
    }
  };

  const handleGenerateReport = () => {
    setShowReportModal(true);
  };

  const handleExportReport = (format) => {
    // Mock report generation
    const reportData = {
      timestamp: new Date().toISOString(),
      auv: selectedAUV,
      timeFrame: timeFrame,
      compliance: complianceRules,
      summary: {
        totalRules: complianceRules.length,
        compliant: complianceRules.filter(rule => rule.status === 'compliant').length,
        violations: complianceRules.filter(rule => rule.status === 'violation').length
      }
    };

    // Create downloadable file
    const dataStr = format === 'json' 
      ? JSON.stringify(reportData, null, 2)
      : convertToCSV(reportData);
    
    const dataBlob = new Blob([dataStr], { type: format === 'json' ? 'application/json' : 'text/csv' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `isa-compliance-report-${selectedAUV}-${new Date().toISOString().split('T')[0]}.${format}`;
    link.click();
    
    setShowReportModal(false);
  };

  const convertToCSV = (data) => {
    const headers = ['Rule ID', 'Rule Name', 'Current Value', 'Threshold', 'Unit', 'Status'];
    const rows = data.compliance.map(rule => [
      rule.id,
      rule.name,
      rule.currentValue,
      rule.threshold,
      rule.unit,
      rule.status
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const overallCompliance = complianceRules.every(rule => rule.status === 'compliant');
  const violationCount = complianceRules.filter(rule => rule.status === 'violation').length;

  return (
    <div className="panel-container compliance-status">
      <div className="panel-header">
        <h3>ISA Compliance Status</h3>
        <div className={`overall-status ${overallCompliance ? 'compliant' : 'violation'}`}>
          <span className="status-icon">
            {overallCompliance ? '✅' : '❌'}
          </span>
          <span>{overallCompliance ? 'Compliant' : `${violationCount} Violation${violationCount > 1 ? 's' : ''}`}</span>
        </div>
      </div>

      <div className="compliance-summary">
        <div className="summary-stats">
          <div className="stat-item">
            <span className="stat-value">{complianceRules.filter(r => r.status === 'compliant').length}</span>
            <span className="stat-label">Compliant</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{violationCount}</span>
            <span className="stat-label">Violations</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{complianceRules.length}</span>
            <span className="stat-label">Total Rules</span>
          </div>
        </div>
      </div>

      <div className="compliance-rules">
        <h4>Compliance Rules</h4>
        {complianceRules.map(rule => (
          <div key={rule.id} className={`rule-card ${rule.status}`}>
            <div className="rule-header">
              <div className="rule-info">
                <span className="rule-id">{rule.id}</span>
                <span className="rule-name">{rule.name}</span>
              </div>
              <div className="rule-status">
                <span className="status-icon">{getComplianceIcon(rule.status)}</span>
                <span className="status-text">{rule.status.toUpperCase()}</span>
              </div>
            </div>
            
            <div className="rule-values">
              <div className="value-item">
                <span className="value-label">Current:</span>
                <span className="value-number">{rule.currentValue} {rule.unit}</span>
              </div>
              <div className="value-item">
                <span className="value-label">Threshold:</span>
                <span className="value-number">{rule.threshold} {rule.unit}</span>
              </div>
            </div>
            
            <div className="rule-progress">
              <div className="progress-bar">
                <div 
                  className="progress-fill"
                  style={{ 
                    width: `${Math.min((rule.currentValue / rule.threshold) * 100, 100)}%`,
                    backgroundColor: getComplianceColor(rule.status)
                  }}
                ></div>
              </div>
              <span className="progress-percentage">
                {((rule.currentValue / rule.threshold) * 100).toFixed(1)}%
              </span>
            </div>
            
            <p className="rule-description">{rule.description}</p>
          </div>
        ))}
      </div>

      <div className="reporting-section">
        <h4>ISA Reporting</h4>
        <div className="reporting-info">
          <div className="info-item">
            <span className="info-label">Last Report:</span>
            <span className="info-value">{data.lastReport}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Reporting Status:</span>
            <span className="info-value">{data.reportingStatus}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Next Report Due:</span>
            <span className="info-value">
              {new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleDateString()}
            </span>
          </div>
        </div>
        
        <button 
          className="btn btn-primary generate-report-btn"
          onClick={handleGenerateReport}
        >
          📋 Generate ISA Report
        </button>
      </div>

      {/* Report Generation Modal */}
      {showReportModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Generate ISA Compliance Report</h3>
              <button 
                className="modal-close"
                onClick={() => setShowReportModal(false)}
              >
                ×
              </button>
            </div>
            
            <div className="modal-body">
              <div className="report-options">
                <div className="option-group">
                  <label>Report Type:</label>
                  <select 
                    value={reportType} 
                    onChange={(e) => setReportType(e.target.value)}
                  >
                    <option value="daily">Daily Report</option>
                    <option value="weekly">Weekly Summary</option>
                    <option value="monthly">Monthly Report</option>
                    <option value="incident">Incident Report</option>
                  </select>
                </div>
                
                <div className="report-preview">
                  <h4>Report Preview</h4>
                  <p>AUV: {selectedAUV}</p>
                  <p>Time Period: {timeFrame}</p>
                  <p>Compliance Status: {overallCompliance ? 'Compliant' : `${violationCount} Violations`}</p>
                  <p>Generated: {new Date().toLocaleString()}</p>
                </div>
              </div>
            </div>
            
            <div className="modal-footer">
              <button 
                className="btn btn-secondary"
                onClick={() => setShowReportModal(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-primary"
                onClick={() => handleExportReport('json')}
              >
                Export JSON
              </button>
              <button 
                className="btn btn-primary"
                onClick={() => handleExportReport('csv')}
              >
                Export CSV
              </button>
            </div>
          </div>
        </div>
      )}

      {timeFrame === 'live' && (
        <div className="live-monitoring">
          <div className="live-indicator">
            <span className="live-dot"></span>
            <span>Live Compliance Monitoring</span>
          </div>
          <p className="monitoring-note">
            Compliance status is monitored continuously. Violations trigger immediate alerts.
          </p>
        </div>
      )}
    </div>
  );
}

export default ComplianceStatus;

