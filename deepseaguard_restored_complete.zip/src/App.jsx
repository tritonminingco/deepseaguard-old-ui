import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import MapView from './components/MapView';
import DataPanel from './components/DataPanel';
import TimeControls from './components/TimeControls';
import AlertSystem from './components/AlertSystem';
import './styles/App.css';

function App() {
  // Core state management
  const [darkMode, setDarkMode] = useState(true);
  const [timeFrame, setTimeFrame] = useState('live');
  const [selectedAUV, setSelectedAUV] = useState(null);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [alerts, setAlerts] = useState([]);
  const [showAlerts, setShowAlerts] = useState(false);

  // Mock alerts data for demonstration
  useEffect(() => {
    setAlerts([
      {
        id: 'alert-1',
        severity: 'high',
        title: 'Proximity Warning',
        message: 'Benthic Octopod detected within 120m of AUV-003',
        time: '2 minutes ago',
        timestamp: new Date(Date.now() - 2 * 60 * 1000)
      },
      {
        id: 'alert-2',
        severity: 'medium',
        title: 'Battery Warning',
        message: 'AUV-003 battery level at 32%',
        time: '15 minutes ago',
        timestamp: new Date(Date.now() - 15 * 60 * 1000)
      },
      {
        id: 'alert-3',
        severity: 'low',
        title: 'Dissolved Oxygen',
        message: 'Levels below optimal range at collection site',
        time: '28 minutes ago',
        timestamp: new Date(Date.now() - 28 * 60 * 1000)
      }
    ]);
  }, []);

  // Handle time frame changes
  const handleTimeFrameChange = (newTimeFrame) => {
    setTimeFrame(newTimeFrame);
  };

  // Handle AUV selection
  const handleAUVSelect = (auvId) => {
    setSelectedAUV(auvId);
  };

  // Handle playback speed changes
  const handlePlaybackSpeedChange = (speed) => {
    setPlaybackSpeed(speed);
  };

  // Toggle dark/light mode
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Handle alert interactions
  const handleAlertClick = () => {
    setShowAlerts(!showAlerts);
  };

  const handleAlertDismiss = (alertId) => {
    setAlerts(alerts.filter(alert => alert.id !== alertId));
  };

  return (
    <div className={`app ${darkMode ? 'dark-mode' : 'light-mode'}`}>
      {/* Header with navigation and controls */}
      <Header 
        timeFrame={timeFrame}
        onTimeFrameChange={handleTimeFrameChange}
        alerts={alerts}
        onAlertClick={handleAlertClick}
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* Main dashboard content - split screen layout */}
      <div className="dashboard-container">
        {/* Left side: 3D Map View */}
        <div className="map-section">
          <MapView 
            timeFrame={timeFrame}
            selectedAUV={selectedAUV}
            onAUVSelect={handleAUVSelect}
            playbackSpeed={playbackSpeed}
          />
          
          {/* Time controls overlay */}
          <TimeControls
            timeFrame={timeFrame}
            onTimeFrameChange={handleTimeFrameChange}
            playbackSpeed={playbackSpeed}
            onPlaybackSpeedChange={handlePlaybackSpeedChange}
          />
        </div>

        {/* Right side: Data Panels */}
        <div className="data-section">
          <DataPanel 
            selectedAUV={selectedAUV}
            timeFrame={timeFrame}
          />
        </div>
      </div>

      {/* Alert System Overlay */}
      {showAlerts && (
        <AlertSystem
          alerts={alerts}
          onClose={() => setShowAlerts(false)}
          onDismiss={handleAlertDismiss}
        />
      )}
    </div>
  );
}

export default App;

