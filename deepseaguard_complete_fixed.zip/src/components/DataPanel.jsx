import { useState, useEffect } from 'react';

function DataPanel({ selectedAUV, timeFrame }) {
  const [activeTab, setActiveTab] = useState('environmental');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  // Mock data for different tabs
  const mockData = {
    environmental: {
      temperature: 4.2,
      salinity: 34.8,
      dissolvedOxygen: 6.5,
      pH: 8.1,
      turbidity: 2.3,
      pressure: 250.7
    },
    operational: {
      batteryLevel: 78,
      depth: 2450,
      speed: 2.3,
      heading: 142,
      missionProgress: 65,
      dataCollected: 1247
    },
    compliance: {
      isaCompliance: 'Compliant',
      lastReport: '2024-06-18 14:30:00',
      violations: 0,
      status: 'Active'
    }
  };

  useEffect(() => {
    setData(mockData[activeTab]);
  }, [activeTab]);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'environmental':
        return (
          <div className="environmental-metrics">
            <h3>Environmental Metrics</h3>
            <div className="metrics-grid">
              <div className="metric-card">
                <div className="metric-label">Temperature</div>
                <div className="metric-value">{data?.temperature?.toFixed(1)}°C</div>
              </div>
              <div className="metric-card">
                <div className="metric-label">Salinity</div>
                <div className="metric-value">{data?.salinity?.toFixed(1)} PSU</div>
              </div>
              <div className="metric-card">
                <div className="metric-label">Dissolved Oxygen</div>
                <div className="metric-value">{data?.dissolvedOxygen?.toFixed(1)} mg/L</div>
              </div>
              <div className="metric-card">
                <div className="metric-label">pH Level</div>
                <div className="metric-value">{data?.pH?.toFixed(2)}</div>
              </div>
              <div className="metric-card">
                <div className="metric-label">Turbidity</div>
                <div className="metric-value">{data?.turbidity?.toFixed(1)} NTU</div>
              </div>
              <div className="metric-card">
                <div className="metric-label">Pressure</div>
                <div className="metric-value">{data?.pressure?.toFixed(1)} bar</div>
              </div>
            </div>
          </div>
        );
      case 'operational':
        return (
          <div className="operational-data">
            <h3>Operational Data</h3>
            <div className="operational-grid">
              <div className="operational-card">
                <div className="operational-label">Battery Level</div>
                <div className="operational-value">{data?.batteryLevel}%</div>
              </div>
              <div className="operational-card">
                <div className="operational-label">Current Depth</div>
                <div className="operational-value">{data?.depth}m</div>
              </div>
              <div className="operational-card">
                <div className="operational-label">Speed</div>
                <div className="operational-value">{data?.speed} m/s</div>
              </div>
              <div className="operational-card">
                <div className="operational-label">Heading</div>
                <div className="operational-value">{data?.heading}°</div>
              </div>
              <div className="operational-card">
                <div className="operational-label">Mission Progress</div>
                <div className="operational-value">{data?.missionProgress}%</div>
              </div>
              <div className="operational-card">
                <div className="operational-label">Data Collected</div>
                <div className="operational-value">{data?.dataCollected} samples</div>
              </div>
            </div>
          </div>
        );
      case 'compliance':
        return (
          <div className="compliance-status">
            <h3>Compliance Status</h3>
            <div className="compliance-grid">
              <div className="compliance-card">
                <div className="compliance-label">ISA Compliance</div>
                <div className="compliance-value">{data?.isaCompliance}</div>
              </div>
              <div className="compliance-card">
                <div className="compliance-label">Last Report</div>
                <div className="compliance-value">{data?.lastReport}</div>
              </div>
              <div className="compliance-card">
                <div className="compliance-label">Violations</div>
                <div className="compliance-value">{data?.violations}</div>
              </div>
              <div className="compliance-card">
                <div className="compliance-label">Status</div>
                <div className="compliance-value">{data?.status}</div>
              </div>
            </div>
          </div>
        );
      default:
        return <div>Select a tab to view data</div>;
    }
  };

  return (
    <div className="data-panel">
      <div className="data-panel-header">
        <h2>Data Panel</h2>
        <div className="tab-selector">
          <button 
            className={activeTab === 'environmental' ? 'active' : ''}
            onClick={() => setActiveTab('environmental')}
          >
            Environmental
          </button>
          <button 
            className={activeTab === 'operational' ? 'active' : ''}
            onClick={() => setActiveTab('operational')}
          >
            Operational
          </button>
          <button 
            className={activeTab === 'compliance' ? 'active' : ''}
            onClick={() => setActiveTab('compliance')}
          >
            Compliance
          </button>
        </div>
      </div>
      
      <div className="data-panel-content">
        {loading ? (
          <div className="loading">Loading data...</div>
        ) : (
          renderTabContent()
        )}
      </div>
      
      <div className="data-panel-footer">
        <div className="data-info">
          <span>AUV: {selectedAUV || 'None selected'}</span>
          <span>Time Frame: {timeFrame}</span>
        </div>
      </div>
    </div>
  );
}

export default DataPanel;

