import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import '../styles/MapView.css';

// Fix for default marker icons in Leaflet with React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Custom AUV marker icon
const auvIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Mock AUV data for development
const mockAUVs = [
  { id: 'AUV-001', name: 'Explorer-1', position: [-14.652, -125.423], depth: 3240, status: 'active', batteryLevel: 78 },
  { id: 'AUV-002', name: 'Surveyor-1', position: [-14.658, -125.427], depth: 3180, status: 'active', batteryLevel: 65 },
  { id: 'AUV-003', name: 'Collector-1', position: [-14.662, -125.419], depth: 3210, status: 'warning', batteryLevel: 32 },
  { id: 'AUV-004', name: 'Sentinel-1', position: [-14.655, -125.430], depth: 3195, status: 'inactive', batteryLevel: 12 },
];

// Mock sediment plume data
const mockPlumes = [
  { id: 'plume-001', center: [-14.657, -125.425], radius: 500, intensity: 0.7 }
];

// Component to update map view when timeFrame changes
function MapUpdater({ timeFrame, auvs }) {
  const map = useMap();
  
  useEffect(() => {
    // In a real app, this would fetch new data based on timeFrame
    console.log(`Map view updated for timeFrame: ${timeFrame}`);
    
    // Center map on the first AUV if available
    if (auvs.length > 0) {
      map.setView(auvs[0].position, 12);
    }
  }, [timeFrame, map, auvs]);
  
  return null;
}

// Plume visualization component
function PlumesLayer({ plumes }) {
  return (
    <>
      {plumes.map(plume => (
        <CircleMarker
          key={plume.id}
          center={plume.center}
          radius={plume.radius / 50} // Scale down for visualization
          pathOptions={{
            fillColor: '#00b4d8',
            fillOpacity: 0.3 * plume.intensity,
            color: '#007ea7',
            weight: 1
          }}
        >
          <Popup>
            <div>
              <h3>Sediment Plume</h3>
              <p>ID: {plume.id}</p>
              <p>Intensity: {(plume.intensity * 100).toFixed(1)}%</p>
              <p>Radius: {plume.radius}m</p>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </>
  );
}

// Main MapView component
function MapView({ timeFrame, onAUVSelect }) {
  const [auvs, setAUVs] = useState(mockAUVs);
  const [plumes, setPlumes] = useState(mockPlumes);
  const [mapMode, setMapMode] = useState('satellite');
  
  useEffect(() => {
    // In a real app, this would fetch AUV data based on timeFrame
    console.log(`Fetching AUV data for timeFrame: ${timeFrame}`);
    
    // Simulate data update
    if (timeFrame !== 'live') {
      // For historical data, we'd fetch from an API
      // This is just a mock implementation
      const historicalAUVs = [...mockAUVs].map(auv => ({
        ...auv,
        position: [
          auv.position[0] + (Math.random() - 0.5) * 0.01,
          auv.position[1] + (Math.random() - 0.5) * 0.01
        ]
      }));
      setAUVs(historicalAUVs);
    } else {
      setAUVs(mockAUVs);
    }
  }, [timeFrame]);
  
  // Handle AUV selection
  const handleAUVClick = (auvId) => {
    onAUVSelect(auvId);
  };
  
  // Toggle between map modes (satellite, bathymetry, etc.)
  const toggleMapMode = () => {
    setMapMode(mapMode === 'satellite' ? 'bathymetry' : 'satellite');
  };

  return (
    <div className="map-view">
      <div className="map-controls">
        <button className="map-control-btn" onClick={toggleMapMode}>
          {mapMode === 'satellite' ? 'Bathymetry View' : 'Satellite View'}
        </button>
      </div>
      
      <MapContainer 
        center={[-14.657, -125.425]} 
        zoom={12} 
        style={{ height: '100%', width: '100%' }}
      >
        {/* Base map layer - would use different tiles for bathymetry in real app */}
        <TileLayer
          url={mapMode === 'satellite' 
            ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
            : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          }
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {/* AUV markers */}
        {auvs.map(auv => (
          <Marker 
            key={auv.id}
            position={auv.position}
            icon={auvIcon}
            eventHandlers={{
              click: () => handleAUVClick(auv.id)
            }}
          >
            <Popup>
              <div>
                <h3>{auv.name}</h3>
                <p>ID: {auv.id}</p>
                <p>Depth: {auv.depth}m</p>
                <p>Status: {auv.status}</p>
                <p>Battery: {auv.batteryLevel}%</p>
              </div>
            </Popup>
          </Marker>
        ))}
        
        {/* This would be implemented with the actual CircleMarker component */}
        {/* <PlumesLayer plumes={plumes} /> */}
        
        {/* Map updater component */}
        <MapUpdater timeFrame={timeFrame} auvs={auvs} />
      </MapContainer>
      
      <div className="map-legend">
        <div className="legend-title">Map Legend</div>
        <div className="legend-item">
          <div className="legend-color" style={{backgroundColor: '#00b4d8'}}></div>
          <div>Active AUV</div>
        </div>
        <div className="legend-item">
          <div className="legend-color" style={{backgroundColor: '#ffd166'}}></div>
          <div>Warning Status</div>
        </div>
        <div className="legend-item">
          <div className="legend-color" style={{backgroundColor: 'rgba(0, 180, 216, 0.3)'}}></div>
          <div>Sediment Plume</div>
        </div>
      </div>
    </div>
  );
}

export default MapView;
