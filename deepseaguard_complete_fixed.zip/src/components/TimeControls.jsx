import { useState, useEffect } from 'react';
import { useWebSocket } from '../utils/apiClient';
import '../styles/TimeControls.css';

function TimeControls({ timeFrame, onTimeFrameChange }) {
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Connect to time sync WebSocket for server time
  const { status: wsStatus } = useWebSocket('time', (data) => {
    if (data.serverTime) {
      setCurrentTime(new Date(data.serverTime));
    }
  });
  
  // Update current time every second when in live mode
  useEffect(() => {
    let interval;
    
    if (timeFrame === 'live') {
      interval = setInterval(() => {
        setCurrentTime(new Date());
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timeFrame]);
  
  // Handle playback controls for historical data
  useEffect(() => {
    let playbackInterval;
    
    if (isPlaying && timeFrame !== 'live') {
      // Simulate playback by advancing time
      playbackInterval = setInterval(() => {
        setCurrentTime(prevTime => {
          const newTime = new Date(prevTime.getTime() + 1000 * playbackRate);
          
          // If we reach current time, stop playback and switch to live
          if (newTime >= new Date()) {
            setIsPlaying(false);
            onTimeFrameChange('live');
            return new Date();
          }
          
          return newTime;
        });
      }, 1000);
    }
    
    return () => {
      if (playbackInterval) clearInterval(playbackInterval);
    };
  }, [isPlaying, playbackRate, timeFrame, onTimeFrameChange]);
  
  // Format current time for display
  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  
  // Toggle play/pause
  const togglePlayback = () => {
    if (timeFrame === 'live') {
      // If in live mode, switch to historical and start playback
      onTimeFrameChange('past_hour');
      setIsPlaying(true);
    } else {
      // Toggle playback state
      setIsPlaying(!isPlaying);
    }
  };
  
  // Change playback rate
  const changePlaybackRate = (rate) => {
    setPlaybackRate(rate);
  };
  
  // Handle time frame selection
  const handleTimeFrameChange = (e) => {
    const newTimeFrame = e.target.value;
    onTimeFrameChange(newTimeFrame);
    
    // Stop playback when switching time frames
    setIsPlaying(false);
  };

  return (
    <div className="time-controls">
      <div className="current-time">
        <span className="time-display">{formatTime(currentTime)}</span>
        <span className="time-label">
          {timeFrame === 'live' ? 'Live Data' : 'Historical Data'}
        </span>
      </div>
      
      <div className="playback-controls">
        <button 
          className="playback-button"
          onClick={togglePlayback}
          title={isPlaying ? 'Pause' : 'Play'}
        >
          {isPlaying ? '⏸' : '▶'}
        </button>
        
        <div className="speed-controls">
          <button 
            className={`speed-button ${playbackRate === 0.5 ? 'active' : ''}`}
            onClick={() => changePlaybackRate(0.5)}
          >
            0.5x
          </button>
          <button 
            className={`speed-button ${playbackRate === 1 ? 'active' : ''}`}
            onClick={() => changePlaybackRate(1)}
          >
            1x
          </button>
          <button 
            className={`speed-button ${playbackRate === 2 ? 'active' : ''}`}
            onClick={() => changePlaybackRate(2)}
          >
            2x
          </button>
          <button 
            className={`speed-button ${playbackRate === 5 ? 'active' : ''}`}
            onClick={() => changePlaybackRate(5)}
          >
            5x
          </button>
        </div>
      </div>
      
      <div className="time-frame-selector">
        <select 
          value={timeFrame} 
          onChange={handleTimeFrameChange}
          className="time-frame-select"
        >
          <option value="live">Live Data</option>
          <option value="past_hour">Past Hour</option>
          <option value="past_6_hours">Past 6 Hours</option>
          <option value="past_day">Past 24 Hours</option>
          <option value="past_week">Past Week</option>
          <option value="past_month">Past Month</option>
        </select>
      </div>
    </div>
  );
}

export default TimeControls;
