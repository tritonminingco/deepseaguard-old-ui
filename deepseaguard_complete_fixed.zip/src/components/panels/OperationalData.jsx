import { useState, useEffect } from 'react';

function OperationalData({ data, timeFrame }) {
  const [operational, setOperational] = useState({
    batteryLevel: 78,
    depth: 2450,
    speed: 2.3,
    heading: 142,
    missionProgress: 65,
    dataCollected: 1247
  });

  useEffect(() => {
    // Simulate operational data updates
    const interval = setInterval(() => {
      setOperational(prev => ({
        batteryLevel: Math.max(0, prev.batteryLevel - Math.random() * 0.1),
        depth: prev.depth + (Math.random() - 0.5) * 10,
        speed: Math.max(0, prev.speed + (Math.random() - 0.5) * 0.2),
        heading: (prev.heading + (Math.random() - 0.5) * 5) % 360,
        missionProgress: Math.min(100, prev.missionProgress + Math.random() * 0.1),
        dataCollected: prev.dataCollected + Math.floor(Math.random() * 3)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="operational-data">
      <h3>Operational Data</h3>
      <div className="operational-grid">
        <div className="operational-card">
          <div className="operational-label">Battery Level</div>
          <div className="operational-value">
            {operational.batteryLevel.toFixed(1)}%
            <div className="battery-bar">
              <div 
                className="battery-fill" 
                style={{ 
                  width: `${operational.batteryLevel}%`,
                  backgroundColor: operational.batteryLevel > 50 ? '#4CAF50' : operational.batteryLevel > 20 ? '#FF9800' : '#F44336'
                }}
              ></div>
            </div>
          </div>
        </div>
        <div className="operational-card">
          <div className="operational-label">Current Depth</div>
          <div className="operational-value">{operational.depth.toFixed(0)}m</div>
        </div>
        <div className="operational-card">
          <div className="operational-label">Speed</div>
          <div className="operational-value">{operational.speed.toFixed(1)} m/s</div>
        </div>
        <div className="operational-card">
          <div className="operational-label">Heading</div>
          <div className="operational-value">{operational.heading.toFixed(0)}°</div>
        </div>
        <div className="operational-card">
          <div className="operational-label">Mission Progress</div>
          <div className="operational-value">
            {operational.missionProgress.toFixed(1)}%
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${operational.missionProgress}%` }}
              ></div>
            </div>
          </div>
        </div>
        <div className="operational-card">
          <div className="operational-label">Data Collected</div>
          <div className="operational-value">{operational.dataCollected} samples</div>
        </div>
      </div>
    </div>
  );
}

export default OperationalData;

