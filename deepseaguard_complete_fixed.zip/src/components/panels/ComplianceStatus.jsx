import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../components/Authentication';
import { ComplianceService } from '../../utils/dataService';
import { DataRepository } from '../../utils/dbConfig';
import '../../styles/ComplianceStatus.css';

/**
 * ISA Compliance Reporting Component
 * Handles compliance status monitoring and report generation
 */
const ComplianceStatus = () => {
  const [complianceData, setComplianceData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('status');
  const [reportType, setReportType] = useState('monthly');
  const [reportFormat, setReportFormat] = useState('pdf');
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setDate(1)).toISOString().split('T')[0], // First day of current month
    endDate: new Date().toISOString().split('T')[0] // Today
  });
  const [reports, setReports] = useState([]);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [reportResult, setReportResult] = useState(null);
  
  const { currentUser, hasRole } = useAuth();
  
  // Load compliance data
  const loadComplianceData = useCallback(async () => {
    try {
      setLoading(true);
      
      // Get compliance status from database
      const data = await DataRepository.getISAComplianceStatus();
      setComplianceData(data);
      
      // Get report list
      const reportList = await ComplianceService.getReportList();
      setReports(reportList);
      
      setError(null);
    } catch (err) {
      console.error('Error loading compliance data:', err);
      setError('Failed to load compliance data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Initial data load
  useEffect(() => {
    loadComplianceData();
    
    // Set up polling for compliance status updates
    const intervalId = setInterval(() => {
      loadComplianceData();
    }, 60000); // Update every minute
    
    return () => clearInterval(intervalId);
  }, [loadComplianceData]);
  
  // Generate ISA report
  const generateReport = async () => {
    if (!currentUser) {
      setError('You must be logged in to generate reports');
      return;
    }
    
    try {
      setGeneratingReport(true);
      setReportResult(null);
      
      // Generate report
      const result = await ComplianceService.generateReport(
        reportType,
        reportFormat,
        {
          startDate: dateRange.startDate,
          endDate: dateRange.endDate
        }
      );
      
      // Create database record
      await DataRepository.generateISAReport(
        reportType,
        new Date(dateRange.startDate),
        new Date(dateRange.endDate),
        currentUser.id
      );
      
      setReportResult(result);
      
      // Refresh report list
      const reportList = await ComplianceService.getReportList();
      setReports(reportList);
      
    } catch (err) {
      console.error('Error generating report:', err);
      setError('Failed to generate report. Please try again.');
    } finally {
      setGeneratingReport(false);
    }
  };
  
  // Download report
  const downloadReport = (reportUrl) => {
    window.open(reportUrl, '_blank');
  };
  
  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get compliance status class
  const getStatusClass = (status) => {
    switch (status) {
      case 'compliant':
        return 'status-compliant';
      case 'warning':
        return 'status-warning';
      case 'critical':
        return 'status-critical';
      default:
        return 'status-unknown';
    }
  };
  
  // Handle date range change
  const handleDateChange = (e) => {
    const { name, value } = e.target;
    setDateRange(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Set date range based on report type
  useEffect(() => {
    const now = new Date();
    let startDate;
    
    switch (reportType) {
      case 'monthly':
        // First day of current month
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'quarterly':
        // First day of current quarter
        const quarter = Math.floor(now.getMonth() / 3);
        startDate = new Date(now.getFullYear(), quarter * 3, 1);
        break;
      case 'annual':
        // First day of current year
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    
    setDateRange({
      startDate: startDate.toISOString().split('T')[0],
      endDate: now.toISOString().split('T')[0]
    });
  }, [reportType]);
  
  return (
    <div className="compliance-status">
      <div className="compliance-header">
        <h2>ISA Compliance</h2>
        
        {/* Tab navigation */}
        <div className="compliance-tabs">
          <button 
            className={`tab-button ${activeTab === 'status' ? 'active' : ''}`}
            onClick={() => setActiveTab('status')}
          >
            Status
          </button>
          <button 
            className={`tab-button ${activeTab === 'reports' ? 'active' : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            Reports
          </button>
          {hasRole('compliance_officer') && (
            <button 
              className={`tab-button ${activeTab === 'generate' ? 'active' : ''}`}
              onClick={() => setActiveTab('generate')}
            >
              Generate Report
            </button>
          )}
        </div>
      </div>
      
      {/* Error message */}
      {error && (
        <div className="compliance-error">
          <p>{error}</p>
          <button onClick={() => setError(null)}>Dismiss</button>
        </div>
      )}
      
      {/* Loading indicator */}
      {loading && (
        <div className="compliance-loading">
          <p>Loading compliance data...</p>
        </div>
      )}
      
      {/* Compliance Status Tab */}
      {activeTab === 'status' && complianceData && (
        <div className="compliance-status-content">
          <div className="compliance-summary">
            <div className={`compliance-indicator ${getStatusClass(complianceData.reportingStatus.compliance)}`}>
              <h3>Overall Compliance</h3>
              <span className="status">{complianceData.reportingStatus.compliance}</span>
            </div>
            
            <div className="reporting-status">
              <div className="status-item">
                <h4>Next Report Due</h4>
                <p>{formatDate(complianceData.reportingStatus.nextReport)}</p>
              </div>
              <div className="status-item">
                <h4>Last Report Submitted</h4>
                <p>{complianceData.reportingStatus.lastReport ? formatDate(complianceData.reportingStatus.lastReport) : 'None'}</p>
              </div>
            </div>
          </div>
          
          <div className="standards-list">
            <h3>ISA Standards Compliance</h3>
            <table className="compliance-table">
              <thead>
                <tr>
                  <th>Standard</th>
                  <th>Description</th>
                  <th>Current Value</th>
                  <th>Threshold</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {complianceData.isaStandards.map(standard => (
                  <tr key={standard.id}>
                    <td>{standard.id}</td>
                    <td>{standard.description}</td>
                    <td>{standard.value}</td>
                    <td>{standard.threshold}</td>
                    <td>
                      <span className={`status-badge ${getStatusClass(standard.status)}`}>
                        {standard.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Reports Tab */}
      {activeTab === 'reports' && (
        <div className="compliance-reports-content">
          <h3>ISA Compliance Reports</h3>
          
          {reports.length > 0 ? (
            <table className="reports-table">
              <thead>
                <tr>
                  <th>Report ID</th>
                  <th>Type</th>
                  <th>Period</th>
                  <th>Status</th>
                  <th>Submitted</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map(report => (
                  <tr key={report.report_id}>
                    <td>{report.report_id}</td>
                    <td>{report.report_type}</td>
                    <td>{formatDate(report.start_date)} - {formatDate(report.end_date)}</td>
                    <td>
                      <span className={`status-badge ${report.status === 'submitted' ? 'status-compliant' : ''}`}>
                        {report.status}
                      </span>
                    </td>
                    <td>{report.submitted_at ? formatDate(report.submitted_at) : 'Not submitted'}</td>
                    <td>
                      {report.report_url && (
                        <button 
                          className="btn btn-primary"
                          onClick={() => downloadReport(report.report_url)}
                        >
                          Download
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="no-reports">
              <p>No reports available</p>
            </div>
          )}
        </div>
      )}
      
      {/* Generate Report Tab */}
      {activeTab === 'generate' && hasRole('compliance_officer') && (
        <div className="generate-report-content">
          <h3>Generate ISA Compliance Report</h3>
          
          <div className="report-form">
            <div className="form-group">
              <label htmlFor="report-type">Report Type</label>
              <select 
                id="report-type"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="annual">Annual</option>
              </select>
            </div>
            
            <div className="form-group">
              <label htmlFor="report-format">Report Format</label>
              <select 
                id="report-format"
                value={reportFormat}
                onChange={(e) => setReportFormat(e.target.value)}
              >
                <option value="pdf">PDF</option>
                <option value="json">JSON</option>
                <option value="xml">XML</option>
              </select>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="start-date">Start Date</label>
                <input 
                  type="date"
                  id="start-date"
                  name="startDate"
                  value={dateRange.startDate}
                  onChange={handleDateChange}
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="end-date">End Date</label>
                <input 
                  type="date"
                  id="end-date"
                  name="endDate"
                  value={dateRange.endDate}
                  onChange={handleDateChange}
                  min={dateRange.startDate}
                  max={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>
            
            <button 
              className="btn btn-primary generate-btn"
              onClick={generateReport}
              disabled={generatingReport}
            >
              {generatingReport ? 'Generating...' : 'Generate Report'}
            </button>
          </div>
          
          {reportResult && (
            <div className="report-result">
              <h4>Report Generated Successfully</h4>
              <p>Report ID: {reportResult.reportId}</p>
              <p>Format: {reportFormat.toUpperCase()}</p>
              <p>Period: {formatDate(dateRange.startDate)} - {formatDate(dateRange.endDate)}</p>
              
              {reportResult.downloadUrl && (
                <button 
                  className="btn btn-success"
                  onClick={() => downloadReport(reportResult.downloadUrl)}
                >
                  Download Report
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ComplianceStatus;
