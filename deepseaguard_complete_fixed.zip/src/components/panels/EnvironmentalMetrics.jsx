import { useState, useEffect } from 'react';

function EnvironmentalMetrics({ data, timeFrame }) {
  const [metrics, setMetrics] = useState({
    temperature: 4.2,
    salinity: 34.8,
    dissolvedOxygen: 6.5,
    pH: 8.1,
    turbidity: 2.3,
    pressure: 250.7
  });

  useEffect(() => {
    // Simulate data updates
    const interval = setInterval(() => {
      setMetrics(prev => ({
        temperature: prev.temperature + (Math.random() - 0.5) * 0.1,
        salinity: prev.salinity + (Math.random() - 0.5) * 0.05,
        dissolvedOxygen: prev.dissolvedOxygen + (Math.random() - 0.5) * 0.2,
        pH: prev.pH + (Math.random() - 0.5) * 0.02,
        turbidity: prev.turbidity + (Math.random() - 0.5) * 0.1,
        pressure: prev.pressure + (Math.random() - 0.5) * 2
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="environmental-metrics">
      <h3>Environmental Metrics</h3>
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-label">Temperature</div>
          <div className="metric-value">{metrics.temperature.toFixed(1)}°C</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Salinity</div>
          <div className="metric-value">{metrics.salinity.toFixed(1)} PSU</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Dissolved Oxygen</div>
          <div className="metric-value">{metrics.dissolvedOxygen.toFixed(1)} mg/L</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">pH Level</div>
          <div className="metric-value">{metrics.pH.toFixed(2)}</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Turbidity</div>
          <div className="metric-value">{metrics.turbidity.toFixed(1)} NTU</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Pressure</div>
          <div className="metric-value">{metrics.pressure.toFixed(1)} bar</div>
        </div>
      </div>
    </div>
  );
}

export default EnvironmentalMetrics;

