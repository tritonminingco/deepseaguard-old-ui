import React, { useState, useEffect, useCallback } from 'react';
import { AlertService } from '../utils/dataService';
import { DataRepository } from '../utils/dbConfig';
import '../styles/AlertSystem.css';

/**
 * Alert System Component
 * Manages real-time alerts, notifications, and alert history
 */
const AlertSystem = ({ currentUser }) => {
  const [activeAlerts, setActiveAlerts] = useState([]);
  const [alertHistory, setAlertHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [notification, setNotification] = useState(null);

  // Load active alerts and set up real-time updates
  useEffect(() => {
    const loadAlerts = async () => {
      try {
        setLoading(true);
        
        // Get active alerts from database
        const alerts = await DataRepository.getAlerts(true);
        setActiveAlerts(alerts);
        
        // Set up WebSocket connection for real-time updates
        const { alerts: wsAlerts, connectionStatus: wsStatus } = AlertService.useRealtimeAlerts();
        
        if (wsAlerts && wsAlerts.length > 0) {
          setActiveAlerts(wsAlerts);
        }
        
        setConnectionStatus(wsStatus);
        setError(null);
      } catch (err) {
        console.error('Error loading alerts:', err);
        setError('Failed to load alerts. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    loadAlerts();
    
    // Set up polling as backup for WebSocket
    const intervalId = setInterval(() => {
      if (connectionStatus !== 'connected') {
        loadAlerts();
      }
    }, 30000); // Poll every 30 seconds if WebSocket is not connected
    
    return () => clearInterval(intervalId);
  }, [connectionStatus]);
  
  // Load alert history when tab is switched
  const loadAlertHistory = useCallback(async () => {
    try {
      setLoading(true);
      const history = await DataRepository.getAlerts(false, 50);
      setAlertHistory(history);
      setError(null);
    } catch (err) {
      console.error('Error loading alert history:', err);
      setError('Failed to load alert history. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);
  
  useEffect(() => {
    if (showHistory) {
      loadAlertHistory();
    }
  }, [showHistory, loadAlertHistory]);
  
  // Handle new alerts
  useEffect(() => {
    // Check for new alerts and show notification
    const checkForNewAlerts = (alerts) => {
      if (!alerts || alerts.length === 0) return;
      
      // Find critical alerts that are not acknowledged
      const criticalAlerts = alerts.filter(
        alert => alert.severity === 'critical' && !alert.acknowledged
      );
      
      if (criticalAlerts.length > 0) {
        // Show notification for the most recent critical alert
        const latestAlert = criticalAlerts.reduce((latest, alert) => {
          return new Date(alert.timestamp) > new Date(latest.timestamp) ? alert : latest;
        }, criticalAlerts[0]);
        
        setNotification({
          id: latestAlert.id,
          message: latestAlert.message,
          severity: latestAlert.severity,
          timestamp: latestAlert.timestamp
        });
        
        // Play sound for critical alerts
        const alertSound = new Audio('/sounds/alert.mp3');
        alertSound.play().catch(e => console.log('Error playing alert sound:', e));
      }
    };
    
    checkForNewAlerts(activeAlerts);
    
    // Set up notification permission
    if (Notification && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
      Notification.requestPermission();
    }
  }, [activeAlerts]);
  
  // Acknowledge alert
  const handleAcknowledge = async (alertId) => {
    if (!currentUser) {
      setError('You must be logged in to acknowledge alerts');
      return;
    }
    
    try {
      await DataRepository.acknowledgeAlert(alertId, currentUser.id);
      
      // Update local state
      setActiveAlerts(alerts => 
        alerts.map(alert => 
          alert.id === alertId ? { ...alert, acknowledged: true } : alert
        )
      );
      
      // Clear notification if it's the acknowledged alert
      if (notification && notification.id === alertId) {
        setNotification(null);
      }
      
      // If in history view, refresh history
      if (showHistory) {
        loadAlertHistory();
      }
    } catch (err) {
      console.error('Error acknowledging alert:', err);
      setError('Failed to acknowledge alert. Please try again.');
    }
  };
  
  // Resolve alert
  const handleResolve = async (alertId) => {
    if (!currentUser) {
      setError('You must be logged in to resolve alerts');
      return;
    }
    
    if (!resolutionNotes.trim()) {
      setError('Resolution notes are required');
      return;
    }
    
    try {
      await DataRepository.resolveAlert(alertId, currentUser.id, resolutionNotes);
      
      // Update local state
      setActiveAlerts(alerts => 
        alerts.map(alert => 
          alert.id === alertId ? { ...alert, resolved: true } : alert
        )
      );
      
      // Clear selected alert and resolution notes
      setSelectedAlert(null);
      setResolutionNotes('');
      
      // If in history view, refresh history
      if (showHistory) {
        loadAlertHistory();
      }
    } catch (err) {
      console.error('Error resolving alert:', err);
      setError('Failed to resolve alert. Please try again.');
    }
  };
  
  // Dismiss notification
  const dismissNotification = () => {
    setNotification(null);
  };
  
  // Get severity class
  const getSeverityClass = (severity) => {
    switch (severity) {
      case 'critical':
        return 'alert-critical';
      case 'warning':
        return 'alert-warning';
      case 'info':
        return 'alert-info';
      default:
        return '';
    }
  };
  
  // Format timestamp
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  return (
    <div className="alert-system">
      {/* Alert notification */}
      {notification && (
        <div className={`alert-notification ${getSeverityClass(notification.severity)}`}>
          <div className="notification-content">
            <h3>Critical Alert</h3>
            <p>{notification.message}</p>
            <p className="notification-time">{formatTimestamp(notification.timestamp)}</p>
          </div>
          <div className="notification-actions">
            <button 
              className="btn btn-primary" 
              onClick={() => handleAcknowledge(notification.id)}
            >
              Acknowledge
            </button>
            <button 
              className="btn btn-secondary" 
              onClick={dismissNotification}
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
      
      <div className="alert-header">
        <h2>Alert System</h2>
        <div className="connection-status">
          <span className={`status-indicator ${connectionStatus}`}></span>
          <span>{connectionStatus === 'connected' ? 'Live' : 'Offline'}</span>
        </div>
      </div>
      
      {/* Tab navigation */}
      <div className="alert-tabs">
        <button 
          className={`tab-button ${!showHistory ? 'active' : ''}`}
          onClick={() => setShowHistory(false)}
        >
          Active Alerts
          {activeAlerts.filter(a => !a.resolved).length > 0 && (
            <span className="alert-count">{activeAlerts.filter(a => !a.resolved).length}</span>
          )}
        </button>
        <button 
          className={`tab-button ${showHistory ? 'active' : ''}`}
          onClick={() => setShowHistory(true)}
        >
          Alert History
        </button>
      </div>
      
      {/* Error message */}
      {error && (
        <div className="alert-error">
          <p>{error}</p>
          <button onClick={() => setError(null)}>Dismiss</button>
        </div>
      )}
      
      {/* Loading indicator */}
      {loading && (
        <div className="alert-loading">
          <p>Loading alerts...</p>
        </div>
      )}
      
      {/* Alert list */}
      <div className="alert-list">
        {!showHistory ? (
          // Active alerts
          activeAlerts.filter(alert => !alert.resolved).length > 0 ? (
            activeAlerts
              .filter(alert => !alert.resolved)
              .sort((a, b) => {
                // Sort by severity (critical first) then by timestamp (newest first)
                if (a.severity === 'critical' && b.severity !== 'critical') return -1;
                if (a.severity !== 'critical' && b.severity === 'critical') return 1;
                return new Date(b.timestamp) - new Date(a.timestamp);
              })
              .map(alert => (
                <div 
                  key={alert.id} 
                  className={`alert-item ${getSeverityClass(alert.severity)} ${alert.acknowledged ? 'acknowledged' : ''}`}
                  onClick={() => setSelectedAlert(alert)}
                >
                  <div className="alert-content">
                    <div className="alert-header">
                      <span className={`severity-indicator ${alert.severity}`}></span>
                      <h3>{alert.type.toUpperCase()}</h3>
                      <span className="alert-time">{formatTimestamp(alert.timestamp)}</span>
                    </div>
                    <p className="alert-message">{alert.message}</p>
                    <p className="alert-source">Source: {alert.source}</p>
                  </div>
                  <div className="alert-actions">
                    {!alert.acknowledged && (
                      <button 
                        className="btn btn-primary"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAcknowledge(alert.id);
                        }}
                      >
                        Acknowledge
                      </button>
                    )}
                    {alert.acknowledged && !alert.resolved && (
                      <button 
                        className="btn btn-success"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedAlert(alert);
                        }}
                      >
                        Resolve
                      </button>
                    )}
                  </div>
                </div>
              ))
          ) : (
            <div className="no-alerts">
              <p>No active alerts</p>
            </div>
          )
        ) : (
          // Alert history
          alertHistory.length > 0 ? (
            alertHistory
              .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
              .map(alert => (
                <div 
                  key={alert.id} 
                  className={`alert-item history ${getSeverityClass(alert.severity)} ${alert.resolved ? 'resolved' : ''}`}
                >
                  <div className="alert-content">
                    <div className="alert-header">
                      <span className={`severity-indicator ${alert.severity}`}></span>
                      <h3>{alert.type.toUpperCase()}</h3>
                      <span className="alert-time">{formatTimestamp(alert.timestamp)}</span>
                    </div>
                    <p className="alert-message">{alert.message}</p>
                    <p className="alert-source">Source: {alert.source}</p>
                    {alert.resolved && (
                      <div className="resolution-info">
                        <p>Resolved: {formatTimestamp(alert.resolved_at)}</p>
                        <p>Notes: {alert.resolution_notes}</p>
                      </div>
                    )}
                  </div>
                  <div className="alert-status">
                    <span className={alert.resolved ? 'status-resolved' : 'status-active'}>
                      {alert.resolved ? 'Resolved' : 'Active'}
                    </span>
                  </div>
                </div>
              ))
          ) : (
            <div className="no-alerts">
              <p>No alert history</p>
            </div>
          )
        )}
      </div>
      
      {/* Resolution modal */}
      {selectedAlert && (
        <div className="resolution-modal">
          <div className="modal-content">
            <h2>Resolve Alert</h2>
            <p className="alert-message">{selectedAlert.message}</p>
            <p className="alert-time">{formatTimestamp(selectedAlert.timestamp)}</p>
            
            <div className="form-group">
              <label htmlFor="resolution-notes">Resolution Notes:</label>
              <textarea 
                id="resolution-notes"
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                placeholder="Enter resolution details..."
                rows={4}
              />
            </div>
            
            <div className="modal-actions">
              <button 
                className="btn btn-success"
                onClick={() => handleResolve(selectedAlert.id)}
                disabled={!resolutionNotes.trim()}
              >
                Resolve Alert
              </button>
              <button 
                className="btn btn-secondary"
                onClick={() => {
                  setSelectedAlert(null);
                  setResolutionNotes('');
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AlertSystem;
