import React, { useState, useEffect, useRef, useCallback, Suspense, ErrorBoundary } from 'react';
import Header from './components/Header';
import DataPanel from './components/DataPanel';
import Map3D from './components/Map3D';
import './styles/App.css';

// Error Boundary Component
class ErrorFallback extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Component Error:", error);
    console.error("Component Stack:", errorInfo.componentStack);
    this.setState({ error, errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-container">
          <h2>Component Error</h2>
          <p>The {this.props.componentName} component failed to render.</p>
          <details>
            <summary>Error Details</summary>
            <p>{this.state.error && this.state.error.toString()}</p>
            <p>Component Stack: {this.state.errorInfo && this.state.errorInfo.componentStack}</p>
          </details>
          <button onClick={() => this.setState({ hasError: false })}>Try Again</button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Remove the lazy loading Map3D component since we're importing it directly
// const Map3D = React.lazy(() => {
//   console.log("Lazy loading Map3D component");
//   return import('./components/Map3D')
//     .then(module => {
//       console.log("Map3D component loaded successfully", module);
//       return module;
//     })
//     .catch(error => {
//       console.error("Error loading Map3D component:", error);
//       throw error;
//     });
// });

function App() {
  console.log("App with Header and Map3D components rendering");
  
  const [count, setCount] = useState(0);
  const [darkMode, setDarkMode] = useState(true);
  const [timeFrame, setTimeFrame] = useState('live');
  const [selectedAUV, setSelectedAUV] = useState(null);
  const [mapError, setMapError] = useState(null);
  
  // Mock alerts data for Header component
  const mockAlerts = [
    {
      id: 'alert-1',
      severity: 'high',
      title: 'Proximity Warning',
      message: 'Benthic Octopod detected within 120m of AUV-003',
      time: '2 minutes ago'
    },
    {
      id: 'alert-2',
      severity: 'medium',
      title: 'Battery Warning',
      message: 'AUV-003 battery level at 32%',
      time: '15 minutes ago'
    },
    {
      id: 'alert-3',
      severity: 'low',
      title: 'Dissolved Oxygen',
      message: 'Levels below optimal range at collection site',
      time: '28 minutes ago'
    }
  ];
  
  useEffect(() => {
    console.log("App with Header and Map3D components mounted");
    console.log("Initial state:", { timeFrame, darkMode, selectedAUV });
    
    // Log when component unmounts
    return () => {
      console.log("App with Header and Map3D components unmounting");
    };
  }, []);

  const incrementCount = () => {
    console.log("Incrementing count");
    setCount(count + 1);
  };

  // Handle time frame changes
  const handleTimeFrameChange = (newTimeFrame) => {
    console.log(`Time frame changed to: ${newTimeFrame}`);
    setTimeFrame(newTimeFrame);
  };

  // Handle AUV selection
  const handleAUVSelect = (auvId) => {
    console.log(`AUV selected: ${auvId}`);
    setSelectedAUV(auvId);
  };

  // Toggle dark/light mode
  const toggleDarkMode = () => {
    console.log(`Toggling dark mode from ${darkMode} to ${!darkMode}`);
    setDarkMode(!darkMode);
  };

  // Handle Map3D errors
  const handleMapError = (error) => {
    console.error("Map3D error caught in App:", error);
    setMapError(error);
  };

  console.log("Rendering with count:", count);

  return (
    <div className={`app ${darkMode ? 'dark-mode' : 'light-mode'}`}>
      {/* Header component with required props */}
      <Header 
        timeFrame={timeFrame}
        onTimeFrameChange={handleTimeFrameChange}
        alerts={mockAlerts}
      />
      
      <div className="main-content">
        {/* Add Map3D component */}
        <div className="map-container">
          <Map3D 
            timeFrame={timeFrame}
            onAUVSelect={handleAUVSelect}
            selectedAUV={selectedAUV}
          />
        </div>
        {/* Add DataPanel component */}
        <div className="data-panel-container">
          <DataPanel 
            selectedAUV={selectedAUV}
            timeFrame={timeFrame}
          />
        </div>
        
        <div className="test-panel">
          <div className="test-card">
            <h2>React Rendering Test</h2>
            <p>This is a simplified version of the app with Header and DataPanel components.</p>
            <p>Current count: {count}</p>
            <button onClick={incrementCount}>Increment Count</button>
          </div>
          
          <div className="test-card">
            <h2>Static Content Test</h2>
            <p>This section contains static content to verify basic HTML rendering.</p>
            <ul>
              <li>Item 1: Basic text rendering</li>
              <li>Item 2: List rendering</li>
              <li>Item 3: Element nesting</li>
            </ul>
          </div>
          
          <div className="test-card">
            <button onClick={toggleDarkMode}>
              {darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            </button>
          </div>
        </div>
      </div>
      
      <footer className="simple-footer">
        <p>DeepSeaGuard v1.0 - Testing Header and Map3D Components</p>
      </footer>
    </div>
  );
}

export default App;
